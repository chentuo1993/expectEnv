#'Fit the EER model
#'
#' Fit the envelope model in linear expectile regression with dimension u.
#' @param X Predictors. An n by p matrix, p is the number of predictors.
#' @param Y Univariate response. An n by 1 matrix or a vector with length n.
#' @param u The dimension of the envelope subspace.
#' @param tau Expectile level. The default value is 0.5.
#' @param maxiter The uplimit of the number of iterations in the optimization algorithm. The default value is 100.
#' @param ftol The convergence tolerance in the optimization algorithm. The default value is 0.01.
#' @return A list consisting of:
#' \item{alpha}{The EER estimator for the intercept.}
#' \item{beta}{The EER estimator for the slope coefficients beta. A vector of length p.}
#' \item{eta_ast}{The EER estimator for eta. A vector of length u.}
#' \item{A}{The EER estimator for A. A (p-u) by u matrix.}
#' \item{G1}{The EER estimator for Gamma. A p by u matirx.}
#' \item{G2}{The EER estimator for Gamma0. A p by (p-u) matrix.}
#' \item{Omega}{The EER estimator for Omega. An u by u matrix.}
#' \item{Omega0}{The EER estimator for Omega0. A (p-u) by (p-u) matrix.}
#' \item{muX}{The EER estimator for the mean of the predictors. A vector of length p.}
#' \item{SigmaX}{The EER estimator for the corvariance matrix of the predictors. A p by p matrix.}
#' \item{paramNum}{The number of parameters in the EER model.}
#' \item{DeltaM_inv}{The EER estimator for the scale matrix.}
#' \item{GEidx}{A vector of length p. The first u elements are the indices of the pivoting rows in the initial estimator of an orthonormal basis matrix of the envelope subspace.}
#' \item{fit_time}{The fit time of the function eenv_gmm.}
#' @details The optimization algorithm is Nelder–Mead method.
#' @import neldermead pls SALES



#' @examples
#' \dontrun{
#' y=state.x77[,5]
#' x=state.x77[,c(1,2,3,7)]
#' xs= scale(x, center = FALSE, scale = apply(x, 2, sd, na.rm = TRUE))
#' eenv_gmm(xs,y,1,0.9)
#' }
#' @export


eenv_gmm<- function(X, Y, u,tau=0.5, maxiter = 1e2,ftol=1e-2) {

  if(u<dim(X)[2]) {
    Gamma_init = unclass(pls::plsr(Y~X,ncomp=u)$loadings)
    GEidx=GE(Gamma_init)
    #GEidx=c(1,4,2,3,5,6,7:dim(X)[2])
    X=X[,GEidx]
  }

  opt2 <- optimset(TolX=ftol,TolFun=ftol,MaxIter=100,MaxFunEvals=300,Display='off')
  t1 = proc.time()

  X <- as.matrix(X)
  Y <- as.matrix(Y)
  n <- nrow(Y)
  r <- ncol(Y)
  p <- ncol(X)
  mX = colMeans(X)
  mY = colMeans(Y)

  W = cbind(rep(1,n),X)
  SX <- stats::cov(X) * (n-1)/n
  ones=matrix(1,n,1)

  ModelOutput=list()

  if (u == p){
    m1=ernet(X,Y,lambda=0,lambda2=0,tau=tau)
    alpha <- as.vector(stats::coef(m1))[1]
    beta=matrix(as.vector(stats::coef(m1))[-1],p,1)

    ModelOutput$alpha = alpha
    ModelOutput$beta = beta
    ModelOutput$paramNum = r + p * r +p + p * (p + 1) / 2;
    ModelOutput$SigmaX = SX
    ModelOutput$muX=mX
  }
  else{
    Gamma_init = unclass(pls::plsr(Y~X,ncomp=u)$loadings)
    G_init = Gamma_init %*% solve(Gamma_init[1:u,])
    A_init = matrix(G_init[-(1:u),],p-u,u)
    G1 = rbind(diag(u),A_init)
    G2 = rbind(-t(A_init),diag(p-u))

    XX=X%*%G1
    m1=ernet(XX,Y,lambda=0,lambda2=0,tau=tau)
    alpha <- as.vector(stats::coef(m1))[1]
    eta_ast=matrix(as.vector(stats::coef(m1))[-1],u,1)
    muX = mX
    Omega = chol2inv(chol(t(G1)%*%G1))%*%t(G1) %*% SX %*% G1%*%chol2inv(chol(t(G1)%*%G1))
    Omega0 = chol2inv(chol(t(G2)%*%G2))%*%t(G2) %*% SX %*% G2%*%chol2inv(chol(t(G2)%*%G2))
    theta0 = c(alpha,muX,A_init,eta_ast,vech(Omega),vech(Omega0))  #initialization

    ### EER objective large vector
    h<-function(theta){
      alpha=theta[1]
      numpar=1
      muX=theta[1:p+numpar]
      numpar=numpar+p
      A = matrix(theta[1:((p-u)*u)+numpar],p-u,u)
      G1 = rbind(diag(u),A)
      G2 = rbind(-t(A),diag(p-u))
      numpar = numpar + (p-u)*u
      eta_ast = matrix(theta[1:u+numpar],u,1)
      numpar = numpar+u
      Omega = inv.vech(theta[1:(u*(u+1)/2)+numpar])
      numpar = numpar+u*(u+1)/2
      Omega0 = inv.vech(theta[1:((p-u)*(p-u+1)/2)+numpar])

      h1 = t(W)%*%((Y-(X%*%G1%*%eta_ast+alpha))*abs((Y<(X%*%G1%*%eta_ast+alpha))-tau))/n
      h2 = vech(G1 %*%Omega%*%t(G1)+G2%*% Omega0 %*%t(G2) -t(X-ones%*%muX)%*%(X-ones%*%muX)/n)
      h3 = muX-mX
      c(h1,h2,h3)
    }
    ### end of EER objective large vector

    f<-function(theta) sum(h(theta)^2) ### EER objective function in stage 1


    ### optimaztion methods
    m0=neldermead::fminsearch(fun=f,x0=theta0,opt2);theta=(m0$optbase)$xopt
    ### end of optimaztion methods


    alpha<-theta[1]
    tmp=1
    muX=theta[1:p+tmp]
    tmp=tmp+p
    A = matrix(theta[1:((p-u)*u)+tmp],p-u,u)
    G1 = rbind(diag(u),A)
    G2 = rbind(-t(A),diag(p-u))
    tmp = tmp + (p-u)*u
    eta_ast = matrix(theta[1:u+tmp],u,1)
    tmp = tmp+u
    Omega = inv.vech(theta[1:(u*(u+1)/2)+tmp])
    tmp = tmp+u*(u+1)/2
    Omega0 = inv.vech(theta[1:((p-u)*(p-u+1)/2)+tmp])
    if(dim(Omega)[1]!=1) {Omega = maxproj.cov(Omega)} else if (Omega<=0) {Omega=1e-04}
    if(dim(Omega0)[1]!=1) {Omega0 = maxproj.cov(Omega0)} else if (Omega0<=0) {Omega0=1e-04}
    theta = c(alpha,muX,A,eta_ast,vech(Omega),vech(Omega0)) ### clarify theta because possible change of Omega and Omega0

    ### generate delta
    DeltaM=0
    for(i in 1:n){
      g1 = t(W[i,])*(as.numeric(Y[i,]-(X[i,]%*%G1%*%eta_ast+alpha))*abs(as.numeric(Y[i,]<(X[i,]%*%G1%*%eta_ast+alpha))-tau))
      g2 = vech(G1%*% Omega %*%t(G1)+G2 %*% Omega0 %*%t(G2)-(X[i,]-muX)%*%t(X[i,]-muX))
      g3 = muX-X[i,]
      gi = c(g1,g2,g3)
      DeltaM = DeltaM+gi%*%t(gi)
    }
    DeltaM=DeltaM/n
    DeltaM_inv=chol2inv(chol(DeltaM+diag(1e-2,ncol(DeltaM))))
    ### end of generate delta

    fnew<-function(theta) {hval=h(theta); hval%*%DeltaM_inv%*%hval} ### EER objective function in stage 2

    m1=neldermead::fminsearch(fun=fnew,x0=theta,opt2);theta=(m1$optbase)$xopt; logobj=(m1$optbase)$fopt



    alpha<-theta[1]
    tmp=1
    muX=theta[1:p+tmp]
    tmp=tmp+p
    A = matrix(theta[1:((p-u)*u)+tmp],p-u,u)
    G1 = rbind(diag(u),A)
    G2 = rbind(-t(A),diag(p-u))
    tmp = tmp + (p-u)*u
    eta_ast = matrix(theta[1:u+tmp],u,1)
    tmp = tmp+u
    Omega = inv.vech(theta[1:(u*(u+1)/2)+tmp])
    tmp = tmp+u*(u+1)/2
    Omega0 = inv.vech(theta[1:((p-u)*(p-u+1)/2)+tmp])
    if(dim(Omega)[1]!=1) {Omega = maxproj.cov(Omega)} else if (Omega<=0) {Omega=1e-04}
    if(dim(Omega0)[1]!=1) {Omega0 = maxproj.cov(Omega0)} else if (Omega0<=0) {Omega0=1e-04}

    beta= G1%*%eta_ast
    ModelOutput$alpha = alpha
    ModelOutput$eta_ast = eta_ast
    ModelOutput$A = A
    ModelOutput$G1 = G1[order(GEidx),]
    ModelOutput$G2=  G2[order(GEidx),]

    # ModelOutput$Gamma=  qr.Q(qr( G1[order(GEidx),]))
    # ModelOutput$Gamma0=  qr.Q(qr(G2[order(GEidx),]))
    ModelOutput$Omega = Omega
    ModelOutput$Omega0 = Omega0
    ModelOutput$muX=muX[order(GEidx)]


    ModelOutput$beta = beta[order(GEidx)]
    ModelOutput$SigmaX = G1[order(GEidx),]%*%Omega%*%t(G1[order(GEidx),])+G2[order(GEidx),]%*%Omega0%*%t(G2[order(GEidx),])

    ModelOutput$paramNum =r + u * r + p + p * (p + 1) / 2
    ModelOutput$DeltaM_inv=DeltaM_inv
    ModelOutput$GEidx=GEidx
  }
  class(ModelOutput) <- "eenv"
  ModelOutput$fit_time=(proc.time()-t1)[3]
  return(ModelOutput)
}
