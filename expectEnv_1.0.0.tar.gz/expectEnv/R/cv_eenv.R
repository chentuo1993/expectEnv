#' Dimension selection for eenv_gmm
#'
#' For each possible envelope subspace dimension, compute the prediction error for the EER estimator using cross validation. Pick the most appropriate envelope subspace dimension based on 'one-standard error' rule.
#' @param X Predictors. An n by p matrix, p is the number of predictors.
#' @param Y Univariate response. An n by 1 matrix or a vector with length n.
#' @param dims Candidate envelope subspace dimension. The default value is integers from 1 to p.
#' @param tau Expectile level. The default value is 0.5.
#' @param fold The number of the cross validation folders. The default value is 5.
#' @param  numcv The number of corss validations. The default value is 1.
#' @return The output is a vector of length 4.
#' \item{u_select}{The selected dimensions based on different criterions. Its first component is derived from cross validation without 'one-standard error' rule based on mean squared prediction error. Its second component is derived from cross validation with 'one-standard error' rule based on mean squared prediction error. Its third component is derived from cross validation without 'one-standard error' rule based on expectile prediction error. Its forth component is derived from cross validation with 'one-standard error' rule based on expectile prediction error. We use its forth component as the dimension selection result for eenv_gmm.}
#' @examples
#' \dontrun{
#' y=state.x77[,5]
#' x=state.x77[,c(1,2,3,7)]
#' xs= scale(x, center = FALSE, scale = apply(x, 2, sd, na.rm = TRUE))
#' cv_eenv(xs,y,0.9)
#' }

#' @export

cv_eenv = function (X, Y, dims=NULL,tau=0.5,  fold = 5, numcv=1)
{
  time1=proc.time()
  X <- as.matrix(X)
  Y <- as.matrix(Y)
  n <- nrow(X)
  p <- ncol(X)
  r <- ncol(Y)
  if(is.null(dims)) dims=1:p

  fold_list=list()
  for(k in 1:numcv){
    tmp=sample(1:n)
    fold_list[[k]] <- split(tmp, rep(1:fold, length = n))
  }

  mspemat = matrix(0,fold*numcv,length(dims))
  dimnames(mspemat)=list(fold=rep(1:fold,numcv),dims=dims)
  RCVmat=mspemat
  for(l in 1:(numcv*fold)){
    i = (l-1)%/%fold+1 # numcv
    j = (l-1)%%fold+1  # fold
    omit <- fold_list[[i]][[j]]
    tempX <- X[-omit,,drop=FALSE]
    tempY <- Y[-omit,,drop=FALSE]
    testX <- X[omit,,drop=FALSE]
    testY <- Y[omit,,drop=FALSE]

    for(k in 1:length(dims)){
      cat('numcv=',i , ', Fold =',j, ', dim=',dims[k] ,'.\n')
      m0 <- eenv_gmm(tempX,tempY,dims[k],tau=tau)
      pred <- matrix(1, nrow(testX),1) %*% t(m0$alpha) + testX %*% m0$beta
      resi <- testY - pred
      RCVmat[l,k] <-mean(resi^2*(tau*(resi>0)+(1-tau)*(resi<=0)))
      mspemat[l,k]= mean(resi^2)
    } # end lambda
  } # numcv

  u_select=matrix(0,1,4)
  colnames(u_select)=c('mspe_min','mspe_1se','RCV_min','RCV_1se')

  mspe <- apply(mspemat, 2, mean)
  mspe_sd <- apply(mspemat, 2, stats::sd)/sqrt(fold*numcv)
  u_select[1] <- dims[which.min(mspe)]
  tmp <- which(mspe<min(mspe)+mspe_sd[which.min(mspe)])
  u_select[2] <- dims[tmp[1]]

  RCV <- apply(RCVmat, 2, mean)
  RCV_sd <- apply(RCVmat, 2, stats::sd)/sqrt(fold*numcv)
  u_select[3] <- dims[which.min(RCV)]
  tmp2 <- which(RCV<min(RCV)+RCV_sd[which.min(RCV)])
  u_select[4] <- dims[tmp2[1]]


  result <- list(u_select=u_select)
  result
}
