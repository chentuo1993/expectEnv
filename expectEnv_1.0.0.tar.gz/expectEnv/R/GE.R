#' Gaussian elimination
#'
#' Gaussian elimination with partial pivoting.
#' @param A An n by p matrix. n must be greater than or equal to p.
#' @details This function performs Gaussian elimination to the input matrix and returns the locations of pivoting elements.

#' @return The output is a vector of length n. The first p elements are the indices of the pivoting elements, ordered accoridng to columns, and the rest n-p elements are the remaining indices from 1 to n.

#' @export


GE <- function(A) {

# Gaussian elimination, p must be less than or equal to n
	a <- dim(A)
	n <- a[1]
	p <- a[2]
	idx <- rep(0, p)
	res.idx <- 1:n

	i <- 1
	while (i <= p) {
		tmp <- max(abs(A[res.idx, i]))
		Stmp <- setdiff(which(abs(A[, i]) == tmp), idx)
		idx[i] <- Stmp[1]
		res.idx <- setdiff(res.idx, idx[i])
		for (j in 1:(n-i)) {
			A[res.idx[j], ] <- A[res.idx[j], ] - A[res.idx[j], i] / A[idx[i], i] * A[idx[i], ]
		}
		i <- i + 1
	}
	c(idx, res.idx)
}
