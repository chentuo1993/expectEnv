#' Vectorize a symmetric matrix
#'
#' Vectorize the lower triangle of a symmetric matrix into a vector.
#' @param x An n by n symmetric matrix, n can be any positive integer.

#' @return A vector of length n(n+1)/2.

#' @export

vech<-function(x)
{
  if (!is.square.matrix(x))
    stop("argument x is not a square numeric matrix")
  return(t(t(x[!upper.tri(x)])))
}


#' Stack a vector
#'
#' Stack a vector into a symmetric matrix. The elements in the vector are used as the elements in the lower triangle of the symmetric matrix.
#' @param y A vector of length n, n must satisfy n=R(R+1)/2 for some positive integer R.

#' @return An R by R symmetric matrix.

#' @export

inv.vech <- function( y ) {
  n <- length(y)
  R <- (sqrt(1+8*n)-1)/2

  if (R!=as.integer(R)) {
    stop ("in function inv.vech:  vector will not fit in square matrix\n")
  }

  res <- matrix(0,R, R)
  res[!upper.tri(res)] <- y
  out=t(res)
  out[!upper.tri(res)] <- y
  return(out)
}


#' Vectorize a matrix
#'
#' Vectorize a matrix into a vector.
#' @param x A m by n matrix, m and n can be any positive integers.

#' @return A vector of length mn.

#' @export
vec<-function (x){
  if (!is.matrix(x)) {
    stop("argument x is not a matrix")
  }
  if (!is.numeric(x)) {
    stop("argument x is not a numeric matrix")
  }
  return(t(t(as.vector(x))))
}


is.square.matrix<-function (x)
{
  if (!is.matrix(x))
    stop("argument x is not a matrix")
  return(nrow(x) == ncol(x))
}
