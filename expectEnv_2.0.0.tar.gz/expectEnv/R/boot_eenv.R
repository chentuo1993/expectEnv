#'Bootstrap for eenv_gmm
#'
#' Compute bootstrap standard error for the EER estimator.
#' @param formula An object of class "formula". It could takes form "response ~ terms" where "response" is the response vector and "terms" is a series of predictors connected by "+". It could also takes form "response ~ predictors matrix".
#' @param u The dimension of the envelope subspace.
#' @param tau Expectile level. The default value is 0.5.
#' @param data An optional data frame which containes the variables in the model.
#' @param B The number of bootstrap samples. A positive integer.
#' @return A list consisting of:
#' \item{bootbeta}{The booststrap estimators for beta. An B by p matrix.}
#' \item{bootse}{The standard error for elements in beta computed by bootstrap.}
#' @details This function computes the bootstrap standard errors for the regression slope coefficients in the EER model by paired bootstrap.
#' @examples
#' \dontrun{
#' set.seed(0401)
#' y=state.x77[,5]
#' x=state.x77[,c(1,2,3,7)]
#' xs= scale(x, center = FALSE, scale = apply(x, 2, sd, na.rm = TRUE))
#' boot_eenv(y~xs,u=1,tau=0.9,B=200)
#' }
#' @export

boot_eenv <- function(formula,u,tau=0.5,data=NULL, B) {

  Y=stats::model.frame(formula,data=data)[,1]
  X=stats::model.matrix(formula,data=data)[,-1]

  X <- as.matrix(X)
  Y <- as.matrix(Y)
  a <- dim(Y)
  n <- a[1]
  r <- a[2]
  p <- ncol(X)

  bootenv <- function(i) {
    sam=sample(1:n, n,replace = T)
    return(eenv_gmm(X[sam,], Y[sam,], u,tau)$beta)
  }

  bootbeta <- lapply(1:B, function(i) bootenv(i))

  bootbeta <- matrix(unlist(bootbeta), nrow = B, byrow = TRUE)
  bootse <- matrix(apply(bootbeta, 2, stats::sd), nrow = p)
  return(list(bootse=bootse,bootbeta=bootbeta))

}
