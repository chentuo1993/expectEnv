#' Expectiles for the mixed normal distribution
#'
#' Return the corresponding expectile at the given level for the mixed normal distribution 0.9N(0,1)+0.1N(1,5).
#' @param w An expectile level between 0 and 1.

#' @return The corresponding expectile.

#' @export

"theoretcial.mix"<-function(w)
{
	f <- 0.1
	f1 <- 1
	f2 <- 1

	while (abs(f1/f2)>1e-10)
	{
		f1=(1-w)*as.numeric(as.character(stats::integrate(function(x){-(x-f)*(0.9*stats::dnorm(x, 0, 1)+0.1*stats::dnorm(x, 1, sqrt(5)))},-Inf,f))[1])+
		w*as.numeric(as.character(stats::integrate(function(x){-(x-f)*(0.9*stats::dnorm(x, 0, 1)+0.1*stats::dnorm(x, 1, sqrt(5)))},f,Inf))[1])
		# first derivative of EQ(Y-f)
		f2=(1-w)*as.numeric(as.character(stats::integrate(function(x){(0.9*stats::dnorm(x, 0, 1)+0.1*stats::dnorm(x, 1, sqrt(5)))},-Inf,f))[1])+
		w*as.numeric(as.character(stats::integrate(function(x){(0.9*stats::dnorm(x, 0, 1)+0.1*stats::dnorm(x, 1, sqrt(5)))},f,Inf))[1])
		## Second derivative of EQ(Y-f)
		if (f2==0) f=f
		else f=f-f1/f2
	}
	return(f)
}


#' Expectiles for the exponential distribution
#'
#' Return the corresponding expectile at the given level for the exponential distribution Exp(1).
#' @param w An expectile level between 0 and 1.

#' @return The corresponding expectile.

#' @export

"theoretcial.exp"<-function(w)
{

		f <- 2
		f1 <- 1
		f2 <- 1

		while (abs(f1/f2)>1e-10)
		{
			f1=(1-w)*as.numeric(as.character(stats::integrate(function(x){-(x-f)*stats::dexp(x,1)},0,f))[1])+
			w*as.numeric(as.character(stats::integrate(function(x){-(x-f)*stats::dexp(x,1)},f,Inf))[1])
			# first derivative of EQ(Y-f)
			f2=(1-w)*as.numeric(as.character(stats::integrate(function(x){stats::dexp(x,1)},0,f))[1])+
			w*as.numeric(as.character(stats::integrate(function(x){stats::dexp(x,1)},f,Inf))[1])
			## Second derivative of EQ(Y-f)
			if (f2==0) f=f
			else f=f-f1/f2
		}
		return(f)
}


#' Expectiles for the standard normal distribution
#'
#' Return the corresponding expectile at the given level for the standard normal distribution.
#' @param w An expectile level between 0 and 1.

#' @return The corresponding expectile.

#' @export

"theoretcial.norm"<-function(w)
{
		f <- 0
		f1 <- 1
		f2 <- 1

		while (abs(f1/f2)>1e-10)
		{
			f1=(1-w)*as.numeric(as.character(stats::integrate(function(x){-(x-f)*stats::dnorm(x,0,1)},-Inf,f))[1])+
			w*as.numeric(as.character(stats::integrate(function(x){-(x-f)*stats::dnorm(x,0,1)},f,Inf))[1])
			# first derivative of EQ(Y-f)
			f2=(1-w)*as.numeric(as.character(stats::integrate(function(x){stats::dnorm(x,0,1)},-Inf,f))[1])+
			w*as.numeric(as.character(stats::integrate(function(x){stats::dnorm(x,0,1)},f,Inf))[1])
			## Second derivative of EQ(Y-f)
			if (f2==0) f=f
			else f=f-f1/f2
		}
		return(f)
}

#' Expectiles for the student's t distribution
#'
#' Return the corresponding expectile at the given level for the student's t distribution t(4).
#' @param w An expectile level between 0 and 1.

#' @return The corresponding expectile.

#' @export

"theoretcial.t"<-function(w)
{
		f <- 0
		f1 <- 1
		f2 <- 1
		while (abs(f1/f2)>1e-10)
		{
			f1=(1-w)*as.numeric(as.character(stats::integrate(function(x){-(x-f)*stats::dt(x,df=4)},-Inf,f))[1])+
			w*as.numeric(as.character(stats::integrate(function(x){-(x-f)*stats::dt(x,df=4)},f,Inf))[1])
			# first derivative of EQ(Y-f)
			f2=(1-w)*as.numeric(as.character(stats::integrate(function(x){stats::dt(x,df=4)},-Inf,f))[1])+
			w*as.numeric(as.character(stats::integrate(function(x){stats::dt(x,df=4)},f,Inf))[1])
			## Second derivative of EQ(Y-f)
			if (f2==0) f=f
			else f=f-f1/f2
		}
		return(f)
}
